/**********************
 * PID控制类定义
 **********************/

#ifndef __PID_H
#define __PID_H

class PidController
{
    public:
        PidController(double kp, double ki, double kd);
        double runOnce(double eIn);
        double getKp(void);
        double getKi(void);
        double getKd(void);
        void setKp(double kp);
        void setKi(double ki);
        void setKd(double kd);
    private:
        double kp, ki, kd, output, e, ep;
};

#endif
