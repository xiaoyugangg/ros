# ROS——Turtlebot3——PID控制3颜色赛道跟踪

## 依赖

* ROS
* ROS依赖：OpenCV
* ROS依赖：AR Track Alvar
* ROS依赖：AR Track Alvar Msgs
* ROS依赖：turtlebot3

上述依赖均可以通过APT安装，也可以在Gitee、Github等网站找到。

## 原理

### 赛道误差识别节点

* 节点名：track_tracking_err_identification_node
* 节点源文件：src/track_tracking_err_identification_node.cpp
* 原理说明：程序中的 track_tracking_err_identification_node 节点的作用是通过 OpenCV 对摄像头图像进行颜色分割，左边线、右边线、中线的列坐标平均值作为左边线、中线和右边线的位置，再与镜头中线列坐标（相机图像列数除以2）相比得到“相对误差率”作为赛道误差。

### 目标距离误差识别节点

* 节点名：target_distance_err_identification_node
* 节点源文件：src/target_distance_err_identification_node.cpp
* 原理说明：通过 AR Track Alvar 提供的二维码识别信息，我们还是可以继续使用摄像头测定目标与摄像头的距离，与期望距离相减得到目标距离误差。

### PID控制节点

* 节点名：pid_control
* 节点源文件：src/pid_control.cpp
* 原理说明：通过目标距离误差识别节点和赛道误差识别节点发送的消息，将误差信息通过PID转为目标速度（X轴线速度和Z轴角速度），达到控制目标

## 使用方法

修改src/vision_node.cpp中的colorCenterLow、colorCenterHigh等，Center、Left、Right代表赛道的中线、左边线和右边线，这些是赛道颜色在HSV空间里的值，Low和High代表低阈值和高阈值。它们具体的作用参见OpenCV的inRange函数介绍。

像其它ROS程序一样，本程序需要在Catkin工作空间中编译，利用 rosrun 等命令执行。

需要先通过 catkin 编译，命令为：

```bash
$ cd /path/to/catkin_ws
$ catkin_make -j4 -l4
```

可以通过roslaunch直接执行程序，命令为：

```bash
$ roslaunch turtlebot3_pid_control my_turtlebot3_pid
```

## 可能遇到的问题

### OpenCV安装

Ubuntu可以通过以下命令直接安装OpenCV：

```bash
$ sudo apt install libopencv-dev libcv-dev -f -y
```

其他系统可能需要自己编译C++的OpenCV库文件，但是一般安装的时候ROS里面会有OpenCV。

### AR Track Alvar 的 MD5 码不匹配问题

如果你是通过Ubuntu的APT安装的 AR Track Alvar Msgs，可能会出现消息文件版本不一致的问题。更改 AlvarMarker.h （如果你是APT安装，一般路径为/opt/ros/xxx/include/ar_track_alvar_msgs/AlvarMarker.h），找到md5那一行，找到报错信息中服务器使用的md5码。
