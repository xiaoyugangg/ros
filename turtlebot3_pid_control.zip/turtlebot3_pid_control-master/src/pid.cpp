/**********************
 * PID控制类实现
 **********************/

#include "pid.h"


PidController::PidController(double kp=1.0, double ki=0.05, double kd=0.0)
{
    this->kp = kp;
    this->ki = ki;
    this->kd = kd;
    this->e = 0.0;
    this->ep = 0.0;
    this->output = 0.0;
}

double PidController::runOnce(double eIn)
{
    double dOutput = 0.0;
    dOutput += this->kp * (eIn - this->e) + this->ki * (eIn) + this->kd * (eIn - 2* this->e + this->ep);
    this->ep = this->e;
    this->e = eIn;
    this->output += dOutput;
    return this->output;
}


double PidController::getKp(void)
{
    return this->kp;
}


double PidController::getKi(void)
{
    return this->ki;
}


double PidController::getKd(void)
{
    return this->kd;
}


void PidController::setKp(double kp)
{
    this->kp = kp;
}


void PidController::setKi(double ki)
{
    this->ki = ki;
}


void PidController::setKd(double kd)
{
    this->kd = kd;
}
