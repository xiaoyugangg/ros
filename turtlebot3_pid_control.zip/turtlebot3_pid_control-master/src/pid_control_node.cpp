/**********************
 *     PID控制节点     *
 **********************/

#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h> // Float64 和 double一样都是64位浮点数
#include <geometry_msgs/Twist.h> // 发布速度消息需要
#include <ros/console.h>
#include <string.h>

#include "pid.h" // PID算法相关

using namespace std;

#define PI              (3.1416)
#define MAX_VEL_X       (50.0)
#define MIN_VEL_X       (-50.0)
#define MAX_ANGULAR_Z   (PI / 2.0)
#define MIN_ANGULAR_Z   (- PI / 2.0)
#define LOOP_RATE_HZ    (25)

#define KP_EX_VX        (5)
#define KI_EX_VX        (0.3)
#define KD_EX_VX        (0.0)

#define KP_EX_AZ        (0.0)
#define KI_EX_AZ        (0.0)
#define KD_EX_AZ        (0.0)

#define KP_EY_VX        (0.0)
#define KI_EY_VX        (0.0)
#define KD_EY_VX        (0.0)

#define KP_EY_AZ        (5)
#define KI_EY_AZ        (0.5)
#define KD_EY_AZ        (0.0)

const string PKG_NAME = "turtlebot3_pid_control";
const string NODE_NAME = "pid_control_node";

double targetTrackingErrCache = 0.0;
double trackTrackingErr = 0.0;
double targetErrRetCodeCache = -1;
double trackErrRetCodeCache = -1;


double threshValue(double val, double min, double max)
{
    double ret;
    if (val > max)
    {
        ret = max;
    }
    else if (val < min)
    {
        ret = min;
    }
    else
    {
        ret = val;
    }
    return ret;
}


void targetErrSubCallback(const std_msgs::Float64::ConstPtr & msgPtr)
{
    if (msgPtr == NULL)
    {
        targetErrRetCodeCache = -1;
    }
    else
    {
        targetErrRetCodeCache = 0;
        targetTrackingErrCache = msgPtr->data;
    }
}


void trackErrSubCallback(const std_msgs::Float64::ConstPtr & msgPtr)
{
    if (msgPtr == NULL)
    {
        trackErrRetCodeCache = -1;
    }
    else
    {
        trackErrRetCodeCache = 0;
        trackTrackingErr = msgPtr->data;
    }
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, NODE_NAME);

    ros::NodeHandle handle;
    ros::Publisher cmdvelPub = handle.advertise<geometry_msgs::Twist>("cmd_vel", 1, true);
    
    ros::Subscriber xErrSub = handle.subscribe(("/" + PKG_NAME + "/target_tracking_err_topic"), 1, &targetErrSubCallback);
    ros::Subscriber yErrSub = handle.subscribe(("/" + PKG_NAME + "/track_tracking_err_topic"), 1, &trackErrSubCallback);

    geometry_msgs::Twist twist;
    geometry_msgs::Vector3 targetLinear;
    geometry_msgs::Vector3 targetAngular;

    ros::Rate loopRate(LOOP_RATE_HZ);

    double velLinearX = 0.0;
    double velAngularZ = 0.0;
    double targetErr = 0.0;
    double trackErr = 0.0;
    int targetErrRet = 0;
    int trackErrRet = 0;

    while(handle.ok())
    {
        ros::spinOnce();
        
        PidController pidTargetErrToVX(KP_EX_VX, KI_EX_VX, KD_EX_VX);
        PidController pidTargetErrToAZ(KP_EX_AZ, KI_EX_AZ, KD_EX_AZ);

        PidController pidTrackErrToVX(KP_EY_VX, KI_EY_VX, KD_EY_VX);
        PidController pidTrackErrToAZ(KP_EY_AZ, KI_EY_AZ, KD_EY_AZ);
        
        if (trackErrRetCodeCache != 0)
        {
            ROS_WARN("Getting error of track tracking failed! Skipping this loop!");
            loopRate.sleep();
            continue;
        }

        if (targetErrRetCodeCache != 0)
        {
            ROS_WARN("Getting error of target tracking failed! Skipping this loop!");
            loopRate.sleep();
            continue;
        }

        targetErr = targetTrackingErrCache;
        ROS_INFO("Error of traget tracking is: [%.3f]", targetErr);
        trackErr = trackErr;
        ROS_INFO("Error of track tracking is: [%.3f]", trackErr);

        velLinearX = threshValue((pidTargetErrToVX.runOnce(targetErr) + pidTrackErrToVX.runOnce(trackErr)), MIN_VEL_X, MAX_VEL_X);
        velAngularZ = threshValue((pidTargetErrToAZ.runOnce(targetErr) + pidTrackErrToAZ.runOnce(trackErr)), MIN_ANGULAR_Z, MAX_ANGULAR_Z);

        targetLinear.x = velLinearX;
        targetLinear.y = 0.0;
        targetLinear.z = 0.0;

        targetAngular.x = 0.0;
        targetAngular.y = 0.0;
        targetAngular.z = velAngularZ;

        twist.linear = targetLinear;
        twist.angular = targetAngular;
        cmdvelPub.publish(twist);
        
        loopRate.sleep();
    }

    ROS_INFO("Exitting...");

    return 0;
}
