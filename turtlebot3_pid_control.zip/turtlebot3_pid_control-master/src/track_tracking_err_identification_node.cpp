/*
 * Turtlebot3 赛道跟踪误差检测节点
 */

#include <ros/ros.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>
#include <sstream>
#include <bits/stdc++.h>
#include <std_msgs/Float64.h>
#include <string.h>

typedef unsigned char   u8;
using namespace std;

#define CAMERA_IN_USE   (0)
#define LOOP_RATE_HZ    (25)
#define BLUR_KNL_LENGTH (5)
#define THRESH_RATE_OF_LINE     (0.01)

const string PKG_NAME = "turtlebot3_pid_control";
const string NODE_NAME = "track_tracking_err_identification_node";

const cv::Scalar colorCenterLow(85, 20, 20);
const cv::Scalar colorCenterHigh(85, 230, 230);
const cv::Scalar colorLeftLow(0, 20, 20);
const cv::Scalar colorLeftHigh(0, 230, 230);
const cv::Scalar colorRightLow(170, 20, 20);
const cv::Scalar colorRightHigh(170, 230, 230);
cv::Size blurKSize = cv::Size2d(5, 5);
cv::Mat morphKernel = cv::Mat(5, 5, CV_8UC1, cv::Scalar(1));


// 带返回码的模板类struct。
template <typename T> struct DataWithRet
{
    T data;
    int retCode;
};


DataWithRet<double> getXErrFromImg(cv::Mat &img, cv::Mat &targetMask, cv::Mat &targetImg)
{
    // 定义与初始化
    cv::Mat imgBluredHsv;
    cv::Mat imgBlured;

    cv::Mat maskLeft;
    cv::Mat maskCenter;
    cv::Mat maskRight;
    // cv::Mat mask;

    cv::Mat maskLeftFiltered;
    cv::Mat maskCenterFiltered;
    cv::Mat maskRightFiltered;
    // cv::Mat maskClose;

    cv::Mat imgMasked;
    
    DataWithRet<double> dataRet;

    double biasOfCameraToCenter;
    double distanceLeftToCenter;
    double distanceCenterToRight;
    double yErr;

    dataRet.data = 0.0;
    dataRet.retCode = 0;
    targetImg = cv::Mat(cv::Scalar(0, 0, 0), img.size);
    
    // 均值滤波、颜色空间转换到HSV、颜色分割提取赛道线
    cv::blur(img, imgBlured, blurKSize);
    cv::cvtColor(imgBlured, imgBluredHsv, cv::COLOR_BGR2HSV);
    
    cv::inRange(imgBluredHsv, colorCenterLow, colorCenterHigh, maskCenter);
    cv::inRange(imgBluredHsv, colorLeftLow, colorLeftHigh, maskLeft);
    cv::inRange(imgBluredHsv, colorRightLow, colorRightHigh, maskRight);

    // 闭操作，去除mask中赛道内的噪点
    cv::morphologyEx(maskCenter, maskCenterFiltered, cv::MORPH_CLOSE, morphKernel);
    cv::morphologyEx(maskLeft, maskLeftFiltered, cv::MORPH_CLOSE, morphKernel);
    cv::morphologyEx(maskRight, maskRightFiltered, cv::MORPH_CLOSE, morphKernel);

    // 开操作，去除mask中赛道外的噪点
    cv::morphologyEx(maskCenterFiltered, maskCenterFiltered, cv::MORPH_CLOSE, morphKernel);
    cv::morphologyEx(maskLeftFiltered, maskLeftFiltered, cv::MORPH_CLOSE, morphKernel);
    cv::morphologyEx(maskRightFiltered, maskRightFiltered, cv::MORPH_CLOSE, morphKernel);

    // int edge[2];
    // edge[0] = (img.size[0] - maskCenterClose.size[0])/2;
    // edge[1] = (img.size[1] - maskCenterClose.size[1])/2;

    //定义、初始化
    double avgYOfCenter = 0.0;
    int cntCenter = 0;
    double avgYOfLeft = 0.0;
    int cntLeft = 0;
    double avgYOfRight = 0.0;
    int cntRight = 0;
    int cntPixels = maskCenterFiltered.size[0] * maskCenterFiltered.size[1];

    // 统计center、left、right有效像素的Y坐标平均值
    for(int i = 0; i < maskCenterFiltered.size[0]; i++)
    {
        for(int j = 0; j < maskCenterFiltered.size[1]; j++)
        {
            if (maskCenterFiltered.at<u8>(i, j) == 255)
            {
                avgYOfCenter = ((avgYOfCenter * cntCenter)+double(j))/(cntCenter+1);
                cntCenter++;
            }
            if (maskLeftFiltered.at<u8>(i, j) == 255)
            {
                avgYOfLeft = ((avgYOfLeft * cntLeft)+double(j))/(cntLeft+1);
                cntLeft++;
            }
            if (maskRightFiltered.at<u8>(i, j) == 255)
            {
                avgYOfRight = ((avgYOfRight * cntRight)+double(j))/(cntRight+1);
                cntRight++;
            }
        }
    }

    // 逻辑判断结果是否有效，有效则retCode为0，代表可以更新数据，否则为-1，代表不能更新数据。
    biasOfCameraToCenter = avgYOfCenter - maskCenterFiltered.size[1]/2;
    distanceLeftToCenter = avgYOfCenter - avgYOfLeft;
    distanceCenterToRight = avgYOfRight - avgYOfCenter;
    bool centerExist = false, leftExist = false, rightExist=false;

    // 如果中心线所占像素占比高于一定值则赛道中心线Y平均值有效，否则无效
    if(double(cntCenter)/double(cntPixels) >= THRESH_RATE_OF_LINE)
    {
        centerExist = true;
    }

    // 如果左边线所占像素占比高于一定值则赛道左边线Y平均值有效，否则无效
    if((double(cntLeft)/double(cntPixels) >= THRESH_RATE_OF_LINE) && (distanceLeftToCenter > 0))
    {
        leftExist = true;
    }

    // 如果右边线所占像素占比高于一定值则赛道右边线Y平均值有效，否则无效
    if((double(cntRight)/double(cntPixels) >= THRESH_RATE_OF_LINE) && (distanceCenterToRight > 0))
    {
        rightExist = true;
    }

    // 根据赛道中线、左边线、右边线的存在情况计算xErr
    if(centerExist)
    {
        if(leftExist && rightExist)
        {
            yErr = pow((pow((biasOfCameraToCenter/distanceLeftToCenter), 2), pow((biasOfCameraToCenter/distanceCenterToRight), 2)), 0.5)/2.0;
            if (biasOfCameraToCenter < 0)
            {
                yErr = -yErr;
            }
            dataRet.data = yErr;
            dataRet.retCode = 0;
        }
        else if(leftExist && !rightExist)
        {
            yErr = biasOfCameraToCenter/distanceLeftToCenter;
            dataRet.data = yErr;
            dataRet.retCode = 0;
        }
        else if(!leftExist && rightExist)
        {
            yErr = biasOfCameraToCenter/distanceCenterToRight;
            dataRet.data = yErr;
            dataRet.retCode = 0;
        }
        else
        {
            dataRet.data = 0.0;
            dataRet.retCode = -1;
        }
    }
    else
    {
        dataRet.data = 0.0;
        dataRet.retCode = -1;
    }

    cv::add(maskCenterFiltered, maskLeftFiltered, targetMask);
    cv::add(targetMask, maskRightFiltered, targetMask);
    img.copyTo(targetImg, targetMask);
    return dataRet;
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, NODE_NAME);
    ros::NodeHandle handle;
    std_msgs::Float64 yErrMsg;
    cv::VideoCapture cap;
    cv::Mat srcImg, targetImg, targetMask;

    ros::Publisher yErrPub = handle.advertise<std_msgs::Float64>(("/" + PKG_NAME + "/y_err_topic"), 1, true);
    ros::Rate loopRate(LOOP_RATE_HZ);
    double yErr = 0.0;
    cap.open(CAMERA_IN_USE);

    if(!cap.isOpened())
    {
        ROS_FATAL("Camera failed to open! Exitting with code -1!");
        return -1;
    }
    while(handle.ok())
    {
        ros::spinOnce();

        cap >> srcImg;
        if(srcImg.empty())
        {
            ROS_WARN("Failed to get source image, skipping this loop!");
            loopRate.sleep();
            continue;
        }

        DataWithRet<double> yErrDataRet = getXErrFromImg(srcImg, targetMask, targetImg);
        cv::imshow("Source image", srcImg);
        cv::imshow("Mask image", targetMask);
        cv::imshow("Target image", targetImg);
        cv::waitKey(1);

        int retCode = yErrDataRet.retCode;
        if (retCode != 0)
        {
            ROS_WARN("Vision node failed to get error of Y, skipping this loop!");
            loopRate.sleep();
            continue;
        }
        yErr = yErrDataRet.data;

        yErrMsg.data = yErr;
        yErrPub.publish(yErrMsg);

        loopRate.sleep();
    }

}
