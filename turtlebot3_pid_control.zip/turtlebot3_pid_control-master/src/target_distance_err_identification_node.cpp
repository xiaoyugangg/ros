/*
 * Turtlebot3 目标距离检测节点，通过二维码识别前车距离
 */

#include <ros/ros.h>
#include <bits/stdc++.h>
#include <std_msgs/Float64.h>
#include <string>
#include <ar_track_alvar_msgs/AlvarMarker.h>

using namespace std;

#define CAMERA_IN_USE   (0)
#define LOOP_RATE_HZ    (25)
#define MAX_CONFIDENCE  (5)

const string PKG_NAME = "turtlebot3_pid_control";
const string NODE_NAME = "target_distance_err_identification_node";
const int TARGET_ID = 101;
const double EXPECTED_DISTANCE = 20.0;

int retCodeCache = 0;
double errCache = 0.0;

typedef unsigned char   u8;

// 带返回码的模板类struct。
template <typename T> struct DataWithRet
{
    T data;
    int retCode;
};

double distance(double x, double y, double z)
{
    return (pow((pow(x, 2.0) + pow(y, 2.0) + pow(z, 2.0)), 0.5));
}

DataWithRet<double> getTargetErrFromAvalarMarkers(ar_track_alvar_msgs::AlvarMarkerConstPtr arMarker)
{
    DataWithRet<double> ret;
    if((arMarker->confidence > MAX_CONFIDENCE) || (arMarker->id != TARGET_ID))
    {
        ret.data = 0.0;
        ret.retCode = -1;
    }
    else
    {
        double x, y, z;
        x = arMarker->pose.pose.position.x;
        y = arMarker->pose.pose.position.y;
        z = arMarker->pose.pose.position.z;
        ret.data = distance(x, y, z) - EXPECTED_DISTANCE;
        ret.retCode = 0;
    }
    return ret;
}

void arTrackSubCallback(ar_track_alvar_msgs::AlvarMarkerConstPtr arMarker)
{
    DataWithRet<double> result = getTargetErrFromAvalarMarkers(arMarker);
    retCodeCache = result.retCode;
    errCache = result.data;
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, NODE_NAME);
    ros::NodeHandle handle;
    std_msgs::Float64 errMsg;

    ros::Subscriber arTrackSub = handle.subscribe("/ar_pose_marker", 10, &arTrackSubCallback);
    ros::Publisher errPub = handle.advertise<std_msgs::Float64>(("/" + PKG_NAME + "/x_err_topic"), 1, true);
    ros::Rate loopRate(25);

    while(handle.ok())
    {
        ros::spinOnce();
        if(retCodeCache != 0)
        {
            ROS_WARN("Target avalar with ID [%d] not found or confidence is too high, skipping this loop!", TARGET_ID);
        }
        else
        {
            errMsg.data = errCache;
            errPub.publish(errMsg);
        }
        loopRate.sleep();
    }
}
